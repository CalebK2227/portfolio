/**
 * @file credit.c
 * @author Caleb Krcil
 * @date 9/23/2021
 * @brief determine if a credit card is valid using Luhn's algorithm.
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define NUM_DIGITS 16
#define VALID 0
#define INVALID -1
#define SIZE 32

void convert_card(int card[], char num[], int num_digits);
void print_card(int card[], int size);
void valid(int card[], int size);

/**
 * Main function
 * Calls other functions and takes user input car number.
 * @param visa array where user input is stored
 * @return zero
 */
int main(void)
{
	
	printf("Please input the card number:\n");
	int card[NUM_DIGITS];
        /* use visa to store the credit card number from stdin */
        char visa[SIZE + 1];
	fgets(visa, NUM_DIGITS + 1, stdin);

	convert_card(card, visa, NUM_DIGITS);
	print_card(card, NUM_DIGITS);
	valid(card, NUM_DIGITS);

	return 0;

}

/**
 * Converts the characters in the array to numbers.
 * @param i temporary value for the array.
 */
void convert_card(int card[], char num[], int num_digits)
{
	int i;

	for(i = 0; i < num_digits; i++)
		card[i] = num[i] - '0';

}

/**
 * Prints the card numbers
 * @param i temporary value for the array.
 */
void print_card(int card[], int size)
{
	int i;

	for (i = 0; i < size; i++)
		printf("card[%d] = %d\n", i, card[i]);
}

/**
 * Performs Luhn's algorithm and prints wether or not the card is valid
 * @param i temporary value for the array.
 * @param sum the sum of the credit card numbers after they are multiplied
 */
void valid(int card[], int size) {
	int i;
	int sum = 0;

	for(i = 14; i >= 0; i -= 2) {
		card[i] = card[i] * 2;
	}
	for(i =0; i < size; i++) {
		if(card[i] > 9) {
			sum += card[i] % 10; 
			sum += card[i] /10;
		}
		else {
			sum += card[i];
		}
	}
	if((sum % 10) == 0) {
		printf("Valid card\n");
	}
	else {
		printf("Invalid card\n");
	}
}
