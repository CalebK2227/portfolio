
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#include "blackbox.h"

#define BUFSIZE 1000

int main()
{
  
}

