#include <stdio.h>

int main (void)
{
	printf("  CCCCCCCCC                      ll                       b\n");
	printf("CC         CC                     l                       b\n");
	printf("C                                 l                       b\n");
	printf("C                                 l                       b\n");
	printf("C                                 l                       b\n");
	printf("C                    aaaa         l         eeee          b bbbb\n");
	printf("C                  aa    aa       l       ee    ee        bb    b\n");
	printf("C                  a      a       l       eeeeeeee        bb    b\n");
	printf("CC         CC      aa    aa       l       e               bb    b\n");
	printf("  CCCCCCCCC          aaaa  a      ll       eeeeeee        bbbbbb\n");
	
	return 0;
}
