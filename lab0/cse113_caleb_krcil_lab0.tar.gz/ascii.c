#include <stdio.h>

int main(void)
{
	printf("______________________________                                /|__ \n");
	printf("|                            |                          __/|_/    |___ \n");
	printf("|                            |                  ssss    |            / \n");
	printf("|   _______        _______   |         tss   sss        /            |   \n");
	printf("|   |     |        |     |   |            sss          /__ BOOOOMMM!! | \n");
	printf("|   |     |        |     |   |                           /            _| \n");
	printf("|   |_____|________|_____|   |                          /__  /| ____/ \n");
	printf("|         |        |         |                             |/ |/ \n");
	printf("|      ___|        |___      |\n");
	printf("|      |              |      |\n");
	printf("|      |   ________   |      |    Issa Creeper from Minecraft!\n");
	printf("|      |  |        |  |      |\n");
	printf("|      |__|        |__|      |\n");
	printf("|____________________________|\n");
	
	return 0;
}
